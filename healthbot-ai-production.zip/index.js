// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
import { randomUUID } from "crypto";
var MemStorage = class {
  diseases;
  symptomAnalyses;
  constructor() {
    this.diseases = /* @__PURE__ */ new Map();
    this.symptomAnalyses = /* @__PURE__ */ new Map();
    this.initializeData();
  }
  initializeData() {
    const initialDiseases = [
      {
        name: "Common Cold",
        category: "Respiratory",
        description: "A viral upper respiratory infection affecting the nose and throat",
        symptoms: ["runny nose", "congestion", "sore throat", "cough", "mild fatigue", "low-grade fever"],
        causes: ["rhinovirus", "coronavirus", "respiratory syncytial virus"],
        prevention: ["frequent handwashing", "avoid close contact with sick people", "don't touch face"],
        treatment: "Rest, fluids, over-the-counter medications for symptom relief",
        severity: "mild",
        isCommon: true
      },
      {
        name: "Influenza (Flu)",
        category: "Respiratory",
        description: "A viral infection that attacks the respiratory system",
        symptoms: ["fever", "body aches", "fatigue", "cough", "sore throat", "headache", "chills"],
        causes: ["influenza A virus", "influenza B virus"],
        prevention: ["annual flu vaccine", "frequent handwashing", "avoid crowds during flu season"],
        treatment: "Rest, fluids, antiviral medications if prescribed early",
        severity: "moderate",
        isCommon: true
      },
      {
        name: "COVID-19",
        category: "Respiratory",
        description: "Infectious disease caused by SARS-CoV-2 virus",
        symptoms: ["fever", "cough", "shortness of breath", "fatigue", "loss of taste or smell", "body aches"],
        causes: ["SARS-CoV-2 virus"],
        prevention: ["vaccination", "mask wearing", "social distancing", "hand hygiene"],
        treatment: "Supportive care, antiviral medications, monoclonal antibodies in some cases",
        severity: "moderate",
        isCommon: true
      },
      {
        name: "Asthma",
        category: "Respiratory",
        description: "A condition where airways narrow and swell, making breathing difficult",
        symptoms: ["shortness of breath", "wheezing", "chest tightness", "coughing"],
        causes: ["allergens", "exercise", "cold air", "stress", "respiratory infections"],
        prevention: ["avoid triggers", "use preventive medications", "maintain healthy weight"],
        treatment: "Bronchodilators, corticosteroids, avoiding triggers",
        severity: "moderate",
        isCommon: true
      },
      {
        name: "Hypertension",
        category: "Cardiovascular",
        description: "High blood pressure that can lead to serious health problems",
        symptoms: ["often no symptoms", "headache", "shortness of breath", "nosebleeds"],
        causes: ["high sodium diet", "lack of exercise", "obesity", "stress", "genetics"],
        prevention: ["healthy diet", "regular exercise", "limit sodium", "manage stress"],
        treatment: "Lifestyle changes, antihypertensive medications",
        severity: "moderate",
        isCommon: true
      },
      {
        name: "Type 2 Diabetes",
        category: "Endocrine",
        description: "A chronic condition affecting how the body processes blood sugar",
        symptoms: ["increased thirst", "frequent urination", "fatigue", "blurred vision", "slow healing"],
        causes: ["insulin resistance", "obesity", "sedentary lifestyle", "genetics"],
        prevention: ["healthy diet", "regular exercise", "maintain healthy weight"],
        treatment: "Diet modification, exercise, medications, blood sugar monitoring",
        severity: "moderate",
        isCommon: true
      },
      {
        name: "Migraine",
        category: "Neurological",
        description: "A type of headache disorder characterized by intense pain",
        symptoms: ["severe headache", "nausea", "sensitivity to light", "sensitivity to sound", "visual disturbances"],
        causes: ["stress", "hormonal changes", "certain foods", "sleep changes", "genetics"],
        prevention: ["identify triggers", "regular sleep", "stress management", "stay hydrated"],
        treatment: "Pain relievers, preventive medications, lifestyle modifications",
        severity: "moderate",
        isCommon: true
      },
      {
        name: "Gastroenteritis",
        category: "Digestive",
        description: "Inflammation of the stomach and intestines",
        symptoms: ["nausea", "vomiting", "diarrhea", "stomach cramps", "fever", "dehydration"],
        causes: ["viral infection", "bacterial infection", "food poisoning", "parasites"],
        prevention: ["proper food handling", "hand hygiene", "avoid contaminated water"],
        treatment: "Rest, fluids, electrolyte replacement, medications for symptoms",
        severity: "mild",
        isCommon: true
      },
      {
        name: "Eczema",
        category: "Skin & Allergies",
        description: "A condition that makes skin red and itchy",
        symptoms: ["itchy skin", "red patches", "dry skin", "skin thickening", "small bumps"],
        causes: ["genetics", "immune system", "environmental triggers", "stress"],
        prevention: ["moisturize regularly", "avoid triggers", "use mild soaps"],
        treatment: "Moisturizers, topical corticosteroids, antihistamines",
        severity: "mild",
        isCommon: true
      },
      {
        name: "Heart Attack",
        category: "Cardiovascular",
        description: "Blockage of blood flow to the heart muscle",
        symptoms: ["chest pain", "shortness of breath", "nausea", "sweating", "arm pain", "jaw pain"],
        causes: ["coronary artery disease", "blood clots", "plaque buildup"],
        prevention: ["healthy diet", "exercise", "no smoking", "manage stress", "regular checkups"],
        treatment: "Emergency medical care, medications, procedures to restore blood flow",
        severity: "emergency",
        isCommon: false
      }
    ];
    initialDiseases.forEach((disease) => {
      const id = randomUUID();
      this.diseases.set(id, { ...disease, id });
    });
  }
  async getDisease(id) {
    return this.diseases.get(id);
  }
  async getDiseaseByName(name) {
    return Array.from(this.diseases.values()).find(
      (disease) => disease.name.toLowerCase() === name.toLowerCase()
    );
  }
  async createDisease(insertDisease) {
    const id = randomUUID();
    const disease = { ...insertDisease, id };
    this.diseases.set(id, disease);
    return disease;
  }
  async getAllDiseases() {
    return Array.from(this.diseases.values());
  }
  async getDiseasesByCategory(category) {
    return Array.from(this.diseases.values()).filter(
      (disease) => disease.category.toLowerCase() === category.toLowerCase()
    );
  }
  async searchDiseases(query) {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.diseases.values()).filter(
      (disease) => disease.name.toLowerCase().includes(lowercaseQuery) || disease.description.toLowerCase().includes(lowercaseQuery) || disease.symptoms.some((symptom) => symptom.toLowerCase().includes(lowercaseQuery))
    );
  }
  async createSymptomAnalysis(insertAnalysis) {
    const id = randomUUID();
    const analysis = {
      ...insertAnalysis,
      id,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.symptomAnalyses.set(id, analysis);
    return analysis;
  }
  async getSymptomAnalysis(id) {
    return this.symptomAnalyses.get(id);
  }
};
var storage = new MemStorage();

// server/services/openai.ts
import OpenAI from "openai";
var openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});
function getFallbackAnalysis(input) {
  const allSymptoms = [...input.selectedSymptoms, ...input.symptoms.toLowerCase().split(/[,\s]+/)].filter((s) => s.length > 2);
  const conditions = [];
  if (allSymptoms.some((s) => ["fever", "cough", "cold", "congestion"].includes(s.toLowerCase()))) {
    conditions.push({
      name: "Common Cold or Flu",
      match: 75,
      description: "Viral upper respiratory infection with typical cold/flu symptoms"
    });
  }
  if (allSymptoms.some((s) => ["headache", "pain", "ache"].includes(s.toLowerCase()))) {
    conditions.push({
      name: "Tension Headache",
      match: 60,
      description: "Common headache often caused by stress, tension, or dehydration"
    });
  }
  if (allSymptoms.some((s) => ["stomach", "nausea", "digestive"].includes(s.toLowerCase()))) {
    conditions.push({
      name: "Digestive Issues",
      match: 65,
      description: "Common digestive problems that may resolve with rest and proper diet"
    });
  }
  if (conditions.length === 0) {
    conditions.push({
      name: "General Symptoms",
      match: 50,
      description: "Your symptoms require proper medical evaluation for accurate diagnosis"
    });
  }
  let urgency = "moderate";
  if (input.duration.includes("More than 2 weeks") || allSymptoms.some((s) => ["emergency", "severe", "chest pain"].includes(s.toLowerCase()))) {
    urgency = "high";
  } else if (input.duration.includes("Less than 1 day")) {
    urgency = "low";
  }
  return {
    possibleConditions: conditions,
    recommendations: [
      "Rest and get adequate sleep",
      "Stay well hydrated by drinking plenty of fluids",
      "Eat nutritious foods to support your immune system",
      "Monitor your symptoms and track any changes",
      "Consult a healthcare provider if symptoms persist or worsen",
      "Seek immediate medical attention if you experience severe symptoms"
    ],
    urgency
  };
}
async function analyzeSymptoms(input) {
  try {
    const prompt = `
You are a medical AI assistant helping with symptom analysis for educational purposes. 
Analyze the following symptoms and provide possible conditions, recommendations, and urgency level.

Symptom Description: ${input.symptoms}
Selected Symptoms: ${input.selectedSymptoms.join(", ")}
Duration: ${input.duration}

Please respond with a JSON object containing:
1. possibleConditions: Array of up to 5 possible conditions with name, match percentage (0-100), and brief description
2. recommendations: Array of general health recommendations (not specific medical advice)
3. urgency: One of "low", "moderate", "high", or "emergency"

Important: This is for educational purposes only. Always recommend consulting healthcare professionals for proper diagnosis and treatment.

Format your response as valid JSON.
    `;
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a medical education AI that provides symptom analysis for educational purposes only. Always emphasize that this is not medical advice and users should consult healthcare professionals. Respond only with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });
    const result = JSON.parse(response.choices[0].message.content || "{}");
    const analysis = {
      possibleConditions: Array.isArray(result.possibleConditions) ? result.possibleConditions.slice(0, 5).map((condition) => ({
        name: condition.name || "Unknown Condition",
        match: Math.max(0, Math.min(100, Number(condition.match) || 0)),
        description: condition.description || "No description available"
      })) : [],
      recommendations: Array.isArray(result.recommendations) ? result.recommendations.slice(0, 10) : ["Rest and stay hydrated", "Monitor your symptoms", "Consult a healthcare provider if symptoms persist or worsen"],
      urgency: ["low", "moderate", "high", "emergency"].includes(result.urgency) ? result.urgency : "moderate"
    };
    console.log("Successfully analyzed symptoms with AI");
    return analysis;
  } catch (error) {
    console.error("OpenAI API error:", error?.message || error);
    console.log("Using fallback educational analysis");
    return getFallbackAnalysis(input);
  }
}

// server/routes.ts
import { z } from "zod";
async function registerRoutes(app2) {
  app2.get("/api/diseases", async (req, res) => {
    try {
      const { category, search } = req.query;
      let diseases;
      if (search && typeof search === "string") {
        diseases = await storage.searchDiseases(search);
      } else if (category && typeof category === "string") {
        diseases = await storage.getDiseasesByCategory(category);
      } else {
        diseases = await storage.getAllDiseases();
      }
      res.json(diseases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch diseases" });
    }
  });
  app2.get("/api/diseases/:id", async (req, res) => {
    try {
      const disease = await storage.getDisease(req.params.id);
      if (!disease) {
        return res.status(404).json({ message: "Disease not found" });
      }
      res.json(disease);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch disease" });
    }
  });
  app2.get("/api/disease-categories", async (req, res) => {
    try {
      const diseases = await storage.getAllDiseases();
      const categories = Array.from(new Set(diseases.map((d) => d.category))).map((category) => {
        const count = diseases.filter((d) => d.category === category).length;
        return { name: category, count };
      });
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  app2.post("/api/analyze-symptoms", async (req, res) => {
    try {
      const validationSchema = z.object({
        symptoms: z.string().min(1, "Please describe your symptoms"),
        selectedSymptoms: z.array(z.string()).default([]),
        duration: z.string().min(1, "Please select symptom duration")
      });
      const validatedData = validationSchema.parse(req.body);
      const analysis = await analyzeSymptoms(validatedData);
      const savedAnalysis = await storage.createSymptomAnalysis({
        symptoms: validatedData.symptoms,
        selectedSymptoms: validatedData.selectedSymptoms,
        duration: validatedData.duration,
        analysis
      });
      res.json(savedAnalysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors
        });
      }
      console.error("Error analyzing symptoms:", error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to analyze symptoms"
      });
    }
  });
  app2.get("/api/analysis/:id", async (req, res) => {
    try {
      const analysis = await storage.getSymptomAnalysis(req.params.id);
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analysis" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
