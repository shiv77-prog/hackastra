HealthBot AI - Production Deployment Package
===========================================

This package contains the complete production build of your HealthBot AI website.

WHAT'S INCLUDED:
- index.js: The production server file
- package.json: Production dependencies
- public/: Static files (HTML, CSS, JavaScript)
- public/index.html: Main HTML file
- public/assets/: Compiled CSS and JavaScript files

REQUIREMENTS:
- Node.js version 18 or higher
- npm (Node Package Manager)

INSTALLATION ON YOUR SERVER:
1. Upload all files to your web hosting server
2. Run: npm install
3. Set your OpenAI API key environment variable (optional)
4. Run: npm start

The server will start on the port specified by your hosting provider (usually port 3000 or 8000).

IMPORTANT NOTES:
- The website works with or without OpenAI API key
- If no API key is provided, it uses the built-in educational analysis system
- All medical information is for educational purposes only
- The website includes professional medical disclaimers

HOSTING PROVIDER COMPATIBILITY:
- Works with Hostinger, Heroku, Vercel, Netlify, and most Node.js hosting providers
- Requires Node.js hosting support (not just static hosting)

For support, ensure your hosting provider supports Node.js applications.